# Bootcamp Frontend G21

### Semana 01

* [Ver ejercicio día 01](https://chimerical-paprenjak-4ca268.netlify.app)