# Github Colaborativo G21

[Link al proyecto de github-colaborativo-g21](https://github.com/victorvzn/github-colaborativo-g21)

```bash
git init
git status
git add index.html
git add .
git add -A
git commit -m "mi mensaje"
git log

git branch -M main

git remote add origin https://github.com/victorvzn/github-colaborativo-g21.git
git push -u origin main

git push origin main
git push

git switch -c victor
git branch

git switch main
git checkout main

git checkout victor
git switch victor
```